//skinnyBot March 28th 2008

#include "AntiDebug.h"

void _cdecl Crash()
{
	uint ErrorType = 0;
	__asm 
	{
		mov ErrorType, ebx
		pop ebx
	}
	
	//itoa(ErrorType, gBuffer, 10);
	sprintf(gBuffer, "Go Away %d", ErrorType);
	MsgBoxError(gBuffer);

	__asm
	{		
		mov eax, 0xDEADBEEF
		xor eax, eax
		jmp eax //CRASH
	}
}

void _cdecl Crash1()
{
	__asm
	{
		rdtsc
		push eax //EIP after ret is the cpu time stamp....CRASH!
		ret
	}
}

bool _cdecl TestEnvironment()
{
	bool bDebugger = false;

	__asm
	{
		//Basic PEB debugger check
		push eax
		mov eax, fs:[0x30]
		movzx eax, byte ptr[eax+0x2]
		test eax, eax
		pop eax
		jnz _Crash
		jmp _Safe

		_Crash:
			mov bDebugger, 1
			push ebx
			mov ebx, 1
			call Crash
		_Safe:
			mov bDebugger, 0
	}
	__asm
	{
		//Check NtGlobalFlags
		push eax
		mov eax, fs:[0x30]
		mov eax, [eax+0x68]
		and eax, 0x70 //1000110
		test eax, eax
		pop eax
		jnz _Crash1
		jmp _Safe1

		_Crash1:
			mov bDebugger, 1
			push ebx
			mov ebx, 2
			call Crash
		_Safe1:
			mov bDebugger, 0
	}
	__asm
	{
		//Check HeapFlags
		push eax
		mov eax, fs:[0x30]
		mov eax, [eax+0x18] //Process heap
		mov eax, [eax+0x10] //Heap Flags
		test eax, eax
		pop eax
		jnz _Crash3
		jmp _Safe3

		_Crash3:
			mov bDebugger, 1
			push ebx
			mov ebx, 3
			call Crash

		_Safe3:
			mov bDebugger, 0
	}

	/* OutputDebugStringA no return...Possibly different OS version dlls
	//Test OutputDebugString
	char *strTemp = "DEBUG";
	__asm
	{
		push eax
		xor eax, eax
		push strTemp
		call OutputDebugStringA
		cmp eax, 1
		pop eax
		jne _Crash4
		jmp _Safe4

		_Crash4:
			mov bDebugger, 1
			push ebx
			mov ebx, 4
			call Crash
		_Safe4:
			mov bDebugger, 0
	}
	*/

	/* 
	//NtQueryInformationProcess passed with DebugPort (Param 7)
	fnNtQueryInformationProcess procNtQueryInformationProcess;

	HMODULE hNtDll = LoadLibrary("ntdll.dll");
	if(hNtDll)
		procNtQueryInformationProcess = (fnNtQueryInformationProcess)GetProcAddress(hNtDll, "NtQueryInformationProcess");
	else
		WindowsError();

	if(!procNtQueryInformationProcess)
	{
		WindowsError();
		FreeLibrary(hNtDll);
	}
	else
	{
		DWORD dwDebugged;
		if(procNtQueryInformationProcess(GetProcessHandle(), (PROCESSINFOCLASS)7, &dwDebugged, 4, 0))
		{
			__asm 
			{
				cmp dwDebugged, 0
				jne _Crash5
				jmp _Safe5
	
				_Crash5:
					mov bDebugger, 1
					push ebx
					mov ebx, 5
					call Crash

				_Safe5:
					mov bDebugger, 0
			}

		}
	}
	*/

	//Alternative check via QueryInformationProcess with param 7
	PBOOL bDebugged;
	CheckRemoteDebuggerPresent(GetProcessHandle(), bDebugged);

	__asm 
	{
		test eax, eax
		jne _Crash5
		jmp _Safe5

		_Crash5:
			mov bDebugger, 1
			push ebx
			mov ebx, 5
			call Crash
		_Safe5:
			mov bDebugger, 0
	}


	/*
	//Test if we can debug our own process
	if(!DebugActiveProcess(GetProcessPID()))
	{
		__asm 
		{
			mov bDebugger, 1
			push ebx
			mov ebx, 6
			call Crash
		}
	}
	else
		bDebugger = 0;
	*/

	if(!bDebugger)
		return true;
	else
		return false;
}

void _cdecl InitalSingleStepCheck()
{
	__asm
	{
		push ss
		pop ss
		pushf
		pop eax
		and eax, 0x100
		or eax, eax
		jnz _Crash	
		jmp _Safe

		_Crash:
			push ebx
			mov ebx, 7
			call Crash

		_Safe:
			ret
	}
}

inline void _cdecl DetectSingleStep()
{
	__asm
	{
		push ecx
		push eax
		rdtsc            
		mov ecx,eax
		rdtsc
		sub eax,ecx
		cmp eax,0FFFh
		pop eax
		pop ecx
		jae _Crash
		jmp _Safe

		_Crash:
			push ebx
			mov ebx, 8
			call Crash
		_Safe:
			ret
	}
}



/*
push offset handler
push dword ptr fs:[0]
mov fs:[0],esp
rdtsc
push eax
xor eax, eax
div eax ;trigger exception
rdtsc
sub eax, [esp] ;ticks delta
add esp, 4
pop fs:[0]
add esp, 4
cmp eax, 10000h ;threshold
jb @not_debugged
@debugged:
...
@not_debugged:
...
handler:
mov ecx, [esp+0Ch]
add dword ptr [ecx+0B8h], 2 ;skip div
xor eax, eax
ret


    WINXPSP2.NTDLL.ReleaseBufferLocation():
        .text:7C973215     mov ecx, [eax+4]                     // we *could* jump as high as this point
        .text:7C973218     add ecx, eax
        .text:7C97321A     mov dword ptr [ecx], 0C0100001h
   ---> .text:7C973220     rdtsc                                // ecx should point to the caller stack
        .text:7C973222     mov [ecx+8], eax                     // save the low dword
        .text:7C973225     mov [ecx+0Ch], edx                   // save the high dword
        .text:7C973228
        .text:7C973228 loc_7C973228:
        .text:7C973228     add esi, 0Ch
        .text:7C97322B     or  eax, 0FFFFFFFFh
        .text:7C97322E     lock xadd [esi], eax                 // esi must point to writeable memory
        .text:7C973232     mov eax, offset _WmipLoggerCount
        .text:7C973237     or  ecx, 0FFFFFFFFh
        .text:7C97323A     lock xadd [eax], ecx
        .text:7C97323E     pop esi                              // esi gets blows away, save/restore if needed
        .text:7C97323F     pop ebp                              // ebp gets blown away, save/restore in caller
        .text:7C973240     retn 4                               // need to pad two DWORDS for RET address


int obfuscated_rdtsc (void)
{
    int stack_space[32];
    
    __asm
    {
            jmp __end
        __begin:
            pop ebx
            mov ecx, esp
            add ecx, 4
            mov esi, esp
            add esi, 0x10
            push ebp
            push 1
            push ebx
            push 2
            push 3
            mov eax, 0x7c973220
            jmp eax
        __end:
            call __begin
            pop ebp
    }

    //printf("%08x:%08x\n", stack_space[1], stack_space[0]);
	return stack_space[0];
}

int main(int argc, char* argv[])
{
    int start;
    int end;
    int threshold = 0x6000;

    start = obfuscated_rdtsc();
    end   = obfuscated_rdtsc();
    
    // observed values range from high 0x3000's to mid 0x4000's on my personal laptop.
    printf("%08x\n", end - start);

    if (end - start > threshold)
        MessageBox(0, "Debugger detected!", "Debugger detected!", 0);

    return 0;
}

CheckProcessHeap endp CheckProcessHeap endp
CheckRDTSC proc CheckRDTSC proc
RDTSC
XOR ECX,ECX XOR ECX, ECX
ADD ECX,EAX ADD ECX, EAX
RDTSC
SUB EAX,ECX SUB EAX, ECX
CMP EAX,0FFFh CMP EAX, 0FFFh
JNB @OllyDetected JNB @ OllyDetected
;invoke MessageBox,0,CTEXT("No debugger detected!"),CTEXT("Execution status:"),MB_OK ; Invoke MessageBox, 0, CTEXT ( "No debugger detected!"), CTEXT ( "Execution status:"), MB_OK
RET
@OllyDetected: @ OllyDetected:
invoke MessageBox,0,CTEXT("Debugger detected!"),CTEXT("Execution status:"),MB_OK Invoke MessageBox, 0, CTEXT ( "Debugger detected!"), CTEXT ( "Execution status:"), MB_OK
invoke ExitProcess,0 Invoke ExitProcess, 0
RET 



*/
//NEEDS WORK




/*
void Win32ShutDown(bool bCrashIfFailed)
{
	

	if(GetVersion()<0x80000000) // NT specific
	{	
		HANDLE hToken; 
		TOKEN_PRIVILEGES tkp; 

		// Get a token for this process. 
		if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken)) 
		{
			if(bCrashIfFailed){ CATCH_PAYLOAD;crash(); }
		}

		// Get the LUID for the shutdown privilege. 
		xLookupPrivilegeValue(NULL, 
			//SeShutdownPrivilegeXorStr<0x2B,20,0x45880ADA>("\x78\x49\x7E\x46\x5A\x44\x55\x5D\x44\x5A\x65\x44\x5E\x4E\x50\x56\x5E\x5B\x58"+0x45880ADA).s
			, &tkp.Privileges[0].Luid); 

		tkp.PrivilegeCount = 1;  // one privilege to set    
		tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED; 

		// Get the shutdown privilege for this process. 
		xAdjustTokenPrivileges(hToken, FALSE, &tkp, 0, (PTOKEN_PRIVILEGES)NULL, 0); 

		if (xGetLastError() != ERROR_SUCCESS) 
		{
			if(bCrashIfFailed){ CATCH_PAYLOAD;crash(); }
		}
	}

	// Shut down the system and force all applications to close. 
	if (!xExitWindowsEx(EWX_SHUTDOWN | EWX_FORCE, 0)) 
	{
		if(bCrashIfFailed){ CATCH_PAYLOAD;crash(); }
	}
}
*/